#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This is the "Hello, World!" program but with nice style


def main():
    print("Hello, World!")


if __name__ == "__main__":
    main()
